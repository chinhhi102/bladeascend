from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops
import numpy as np
FONT='/tmp/fonts/Pattaya-Regular.ttf'
def frame_rgba():
    im=Image.open('/tmp/khung.jpg').convert('RGB'); a=np.array(im).astype(float)
    r,g,b=a[...,0],a[...,1],a[...,2]
    # magenta-ness: high r & b, low g
    m=np.clip(((r+b)/2 - g - 60)/80,0,1)
    alpha=(1-m)*255
    # despill: pull magenta tint out of edge pixels
    out=a.copy()
    spill=np.clip((r+b)/2-g,0,None)*m
    out[...,0]-=spill*0.5; out[...,2]-=spill*0.5
    rgba=np.dstack([np.clip(out,0,255),alpha]).astype(np.uint8)
    img=Image.fromarray(rgba,'RGBA')
    return img.crop(img.getbbox())
def text_layer(lines, box_w, box_h, size_max=140):
    # find font size so all lines fit
    for size in range(size_max,20,-2):
        ft=ImageFont.truetype(FONT,size)
        dims=[ft.getbbox(l) for l in lines]
        ws=[d[2]-d[0] for d in dims]; hs=[d[3]-d[1] for d in dims]
        gap=int(size*0.12)
        if max(ws)<=box_w and sum(hs)+gap*(len(lines)-1)<=box_h: break
    pad=40
    W=box_w+pad*2; H=box_h+pad*2
    mask=Image.new('L',(W,H),0); d=ImageDraw.Draw(mask)
    total=sum(hs)+gap*(len(lines)-1); y=(H-total)//2
    for l,dm,w,h in zip(lines,dims,ws,hs):
        d.text(((W-w)//2-dm[0], y-dm[1]), l, font=ft, fill=255); y+=h+gap
    stroke=mask.filter(ImageFilter.MaxFilter(int(size*0.13)|1))
    shadow=stroke.filter(ImageFilter.GaussianBlur(size*0.06))
    # gold gradient
    grad=np.zeros((H,W,3))
    t=np.linspace(0,1,H)[:,None]
    top=np.array([255,240,170]); mid=np.array([245,190,60]); bot=np.array([170,95,20])
    g=np.where(t<0.5, top+(mid-top)*(t/0.5)[...,None] if False else 0,0)
    tt=np.repeat(t,W,axis=1)
    c=np.where(tt[...,None]<0.5, top+(mid-top)*(tt[...,None]/0.5), mid+(bot-mid)*((tt[...,None]-0.5)/0.5))
    gold=Image.fromarray(c.astype(np.uint8),'RGB')
    out=Image.new('RGBA',(W,H),(0,0,0,0))
    sh=Image.new('RGBA',(W,H),(30,10,0,200)); out.paste(sh,(int(size*0.05),int(size*0.07)),shadow)
    st=Image.new('RGBA',(W,H),(62,28,8,255)); out.paste(st,(0,0),stroke)
    out.paste(gold.convert('RGBA'),(0,0),mask)
    # highlight line
    hl=mask.filter(ImageFilter.MinFilter(5)); hla=np.array(hl).astype(float)
    hl_top=(np.linspace(1,0,H)[:,None]**3)*np.ones((1,W))
    hla=(hla*hl_top*0.5).astype(np.uint8)
    out.paste(Image.new('RGBA',(W,H),(255,255,230,255)),(0,0),Image.fromarray(hla))
    return out
def compose(lines,name,stretch=1.0):
    fr=frame_rgba()
    if stretch!=1.0:
        fr=fr.resize((fr.width,int(fr.height*stretch)),Image.LANCZOS)
    # interior relative to crop: original interior 283-1097 x, 296-472 y ; crop offset
    full=Image.open('/tmp/khung.jpg')
    bbox=frame_rgba  # recompute offset
    im=Image.open('/tmp/khung.jpg').convert('RGB'); a=np.array(im).astype(float)
    m=np.clip(((a[...,0]+a[...,2])/2-a[...,1]-60)/80,0,1)
    ys,xs=np.where(m<0.5); ox,oy=xs.min(),ys.min()
    ix0,ix1,iy0,iy1=283-ox,1097-ox,int((296-oy)*stretch),int((472-oy)*stretch)
    bw=int((ix1-ix0)*0.9); bh=int((iy1-iy0)*0.86)
    tl=text_layer(lines,bw,bh)
    canvas=Image.new('RGBA',(fr.width,fr.height),(0,0,0,0)); canvas.alpha_composite(fr)
    cx=(ix0+ix1)//2; cy=(iy0+iy1)//2
    canvas.alpha_composite(tl,(cx-tl.width//2, cy-tl.height//2))
    canvas.save(f'/mnt/user-data/outputs/logo/{name}.png')
    for bgname,bg in [('toi',(28,22,18,255)),('sang',(250,243,226,255))]:
        p=Image.new('RGBA',(canvas.width+80,canvas.height+80),bg); p.alpha_composite(canvas,(40,40)); p.convert('RGB').save(f'/tmp/prev_{name}_{bgname}.jpg',quality=88)
    return canvas
compose(['Đạo Hữu','Xin Dừng Bước'],'logo_vi_2dong',stretch=1.45)
compose(['Đạo Hữu Xin Dừng Bước'],'logo_vi_1dong',stretch=1.0)
compose(['BladeAscend'],'logo_en',stretch=1.0)
print('ok')
